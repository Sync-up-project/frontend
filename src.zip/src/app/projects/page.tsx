"use client";

import { useEffect } from "react";
import ProjectsClient from "./ProjectsClient";
import { useI18n } from "@/lib/i18n";

export default function ProjectsPage() {
  const { tr, lang } = useI18n();

  useEffect(() => {
    // ✅ 언어 전환 시 브라우저 탭 제목도 같이 변경
    document.title = tr("프로젝트 | Sync Up", "プロジェクト | Sync Up");
  }, [lang, tr]);

  return <ProjectsClient />;
}
